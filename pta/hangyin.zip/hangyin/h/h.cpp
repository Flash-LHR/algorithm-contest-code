#include <bits/stdc++.h>
using namespace std;

typedef double db;
typedef long long ll;

const int M = (int)4;
const ll linf = 0x3f3f3f3f3f3f3f3f;

void work() {
	string a, b;
	cin >> a >> b;
	cout << a << "\n";
}

int main() {
	int T = 1; //scanf("%d", &T);
	while(T--) work();
	return 0;
}
