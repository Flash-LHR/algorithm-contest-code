#include <bits/stdc++.h>
using namespace std;

typedef long long ll;

const int M = (int)1e5;

void work() {
	ll n; scanf("%lld", &n);
	if(n < 2431) printf("0\n");
	else printf("1\n");
}

int main() {
	work();
	return 0;
}
